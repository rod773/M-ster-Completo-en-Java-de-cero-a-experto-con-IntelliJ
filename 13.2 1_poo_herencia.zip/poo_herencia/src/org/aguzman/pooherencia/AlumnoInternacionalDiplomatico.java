package org.aguzman.pooherencia;

public class AlumnoInternacionalDiplomatico extends Alumno{
    
}
