package org.aguzman.app.hogar;

class Gato {
}
