package org.aguzman.app.hogar;

public enum ColorPelo {
    NEGRO, CAFE, CASTANIO, RUBIO, COLORIN
}
